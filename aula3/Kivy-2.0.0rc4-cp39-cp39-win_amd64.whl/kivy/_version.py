# This file is imported from __init__.py and exec'd from setup.py

MAJOR = 2
MINOR = 0
MICRO = 0
RELEASE = False

__version__ = '%d.%d.%d' % (MAJOR, MINOR, MICRO)

if not RELEASE:
    # if it's a rcx release, it's not proceeded by a period. If it is a
    # devx release, it must start with a period
    __version__ += 'rc4'


_kivy_git_hash = '5d2131e4551cdd7c0197640b8502076cb7da2e19'
_kivy_build_date = '20201017'

